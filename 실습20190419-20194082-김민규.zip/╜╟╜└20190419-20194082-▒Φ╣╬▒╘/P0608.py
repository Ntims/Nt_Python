count = 1
sum = 0
while count <= 10:
    sum = sum + count
    count = count + 1
print("합계는",sum)
