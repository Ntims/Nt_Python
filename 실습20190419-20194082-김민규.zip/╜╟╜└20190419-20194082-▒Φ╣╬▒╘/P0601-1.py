for letter in "Python":
    print("Current letter :",letter)

print()

fruits = ["banana", "apple", "mango"]
for fruit in fruits:
    print("Current fruit:",fruit)

print("Using Index")
for index in range(len(fruits)):
    print("Current fruit:", fruits[index])
