for i in [1, 2, 3, 4, 5, 6, 7, 8, 9]:
    print("9*"+str(i), "=", 9*i)
