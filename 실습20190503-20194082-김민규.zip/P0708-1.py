def greet(name, hello="안녕!",ag="별일없죠?"):
    print(hello, name+"," ,ag)

greet("홍길동")
greet("홍길동님", "안녕하세요.")
greet("홍길동님","","다음에 뵙겠습니다.")
