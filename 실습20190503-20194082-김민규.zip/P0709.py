def calc(x,y,z):
    return x+2*y+z

a = calc(y=20, x=10, z=30)
print(a)

print(calc(x=20, y=10, z=30))
