def greet(name, msg="별일없죠?"):
    print("안녕", name+","+msg)

greet("홍길동")
