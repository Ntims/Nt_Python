outfile = open("phones1.txt", "w")

outfile.write("홍길동 010-1234-5678")
outfile.write("김철수 010-1234-5679")
outfile.write("김영희 010-1234-5680")

outfile.close()
