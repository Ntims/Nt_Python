infile = open("phones.txt", "r")
lines = infile.read()
print(lines)
infile.close()
